
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kishore_fitness";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$full_name = $_POST['fullName'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$plan = $_POST['plan'];

$stmt = $conn->prepare("INSERT INTO members (full_name, email, phone, plan) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $full_name, $email, $phone, $plan);
$stmt->execute();

if ($stmt->affected_rows > 0) {
  echo "Success";
} else {
  echo "Error: Unable to submit form.";
}

$stmt->close();
$conn->close();
?>
